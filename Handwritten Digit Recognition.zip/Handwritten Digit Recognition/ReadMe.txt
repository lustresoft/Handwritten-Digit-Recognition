=============Handwritten Number Recognition System===========

1.Install Python
2.Install PyCharm
3.Open PyCharm > Open the project folder
4.File > Setttings > install the necessary Packages
5.Run the Application.